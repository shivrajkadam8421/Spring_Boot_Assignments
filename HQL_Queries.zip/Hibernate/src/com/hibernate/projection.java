package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class projection {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
	
		//criteria.setProjection(Projections.property("salary"));
		
		ProjectionList ps=Projections.projectionList();
		ps.add(Projections.property("salary"));
		ps.add(Projections.property("ename"));
		
		criteria.setProjection(ps);
		
		List<Object[]> list= criteria.list();
		
		for(Object[] ar:list) {
			System.out.println(ar[0]+" "+ar[1]);
		}

		System.out.println(list);

		session.beginTransaction().commit();
		
//		List<Employee[]> list=criteria.list();
//		for(Employee[] employee:list) {
//			System.out.println(employee[0]+" "+employee[1]);
		
		
	}

}
