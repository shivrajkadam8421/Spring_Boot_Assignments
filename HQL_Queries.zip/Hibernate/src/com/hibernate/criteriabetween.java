package com.hibernate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class criteriabetween {
	
	public static void main(String[] args) {
		// here if we want data based on non id values then get() and load()
		// methods are not applicable so at that we using criteria.
		
		
		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();

		
		
		
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.between("salary", 5000, 100000));
		List<Employee> li=criteria.list();
		System.out.println(li);
		
//		criteria.add(Restrictions.ilike("salary",5000));
//		List<Employee> li2=criteria.list();
//		System.out.println(li2);
		
		
	}
}
