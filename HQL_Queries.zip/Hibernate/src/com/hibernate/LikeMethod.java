package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class LikeMethod {
	
	//like method gives if we want records which is starting letter s
	// so there we using %s
	public static void main(String[] args) {
		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		//criteria.add(Restrictions.ilike("ename", "s%"));
		
		criteria.add(Restrictions.like("ename", "%s%"));
		
		List<Employee> li=criteria.list();//here we using list cause we get
		// multiple records or multiple objects so we using list we store one by one
//		
//		System.out.println(li);
		for(Employee list:li) {
			System.out.println(list);
		}
	}

}
