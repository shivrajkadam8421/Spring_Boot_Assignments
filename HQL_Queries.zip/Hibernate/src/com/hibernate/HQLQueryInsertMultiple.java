package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import java.util.ArrayList;
public class HQLQueryInsertMultiple {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		
		
	
	
		//if we want to insert multiple records then we have to creating multiple object
		//and creating list
		
		
		ArrayList<Employee> li=new ArrayList<Employee>();
		
		Employee e1=new Employee();
		e1.setEid(70);
		e1.setEname("php");
		e1.setSalary(45000);
		
		
		
		
		Employee e2=new Employee();
		e2.setEid(8);
		e2.setEname("python");
		e2.setSalary(55000);
		
		
		Employee e3=new Employee();
		e3.setEid(9);
		e3.setEname("angular");
		e3.setSalary(65000);
		
		
		li.add(e1);
		li.add(e2);
		li.add(e3);
		
		for (Employee employee : li) {
			
			session.save(employee);
			
		}
		
session.beginTransaction().commit();
		
		}

}
