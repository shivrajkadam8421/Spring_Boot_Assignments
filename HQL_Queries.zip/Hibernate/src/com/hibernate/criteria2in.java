package com.hibernate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class criteria2in {
	
	public static void main(String[] args) {
		// here if we want data based on non id values then get() and load()
		// methods are not applicable so at that we using criteria.
		
		
		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();

		// here we using .in() method using this we get multiple records at a time
		// in(stringpropertyname,object...values)==> this is syntax
		// here object means taking any data from your database 
		// and this object value called variable because it taking multiple values
		//of datatype;
		
		
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.in("ename","sandhya","aniket","nikita"));
		List<Employee> li=criteria.list();
		System.out.println(li);
		
		Criteria criteria1=session.createCriteria(Employee.class);
	criteria.add(Restrictions.in("salary",50000,5000,100000));
		List<Employee> li1=criteria.list();
		System.out.println(li1);
		
		
		//using collection
		Criteria criteria2=session.createCriteria(Employee.class);
		
		Collection collection=new ArrayList();
		collection.add(50000);
		collection.add(4345);
		
		criteria2.add(Restrictions.in("salary",collection));
		List<Employee> li2=criteria2.list();
		System.out.println(li2);
	}
}
