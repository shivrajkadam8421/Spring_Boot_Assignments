//HQL query for delete record 
package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import java.util.ArrayList;
public class HQLQueryDelete {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		
		Transaction ts=session.beginTransaction();
		
//		Query query=session.createQuery("delete from Employee");
//		
//		query.executeUpdate();
//		
//		
//		ts.commit();
		
		
		//delete on perticular row
		
		Query query=session.createQuery("delete from Employee where eid=:empid");
		
		query.setParameter("empid", 1);
		query.executeUpdate();
		
//		ts.commit();
//		
//		Transaction ts1=session.beginTransaction();
//		
		Query query1=session.createQuery("delete from Employee where eid=:empid and ename=:name");
		
		query1.setParameter("empid", 2);
		query1.setParameter("name", "aniket");
        query1.executeUpdate();
		
		ts.commit();
		
	}

}
