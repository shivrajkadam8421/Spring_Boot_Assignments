package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class addMultiple {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		//criteria.add(Restrictions.add(Restrictions.between("salary", 5000, 800000),Restrictions.ge("salary", 100000),Restrictions.isEmpty("salary")));
		
		criteria.add(Restrictions.or(Restrictions.between("salary", 5000, 800000),Restrictions.ge("salary", 100000)));
		
		
		List<Employee> list= criteria.list();
		System.out.println(list);

		//session.beginTransaction().commit();
		
	}

}
