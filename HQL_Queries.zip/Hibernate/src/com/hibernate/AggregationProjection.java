package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import java.util.ArrayList;
public class AggregationProjection {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		//System.out.println(criteria.setProjection(Projections.max("salary")));
		
		criteria.setProjection(Projections.max("salary"));
		
//		criteria.setProjection(Projections.min("salary"));
//		
//		criteria.setProjection(Projections.avg("salary"));
//		
//		criteria.setProjection(Projections.sum("salary"));
//		
//		criteria.setProjection(Projections.count("salary"));
		
	
    		List<Integer> list=criteria.list();
    		System.out.println(list);
		
		
	}

}
