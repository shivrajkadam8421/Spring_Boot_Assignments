package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import java.util.ArrayList;
public class HQLQueryInsert {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		
		
	//	Employee employee=new Employee(103,"java",50000);
		
		
		// this for single record insert into employee
		Employee employee=new Employee();
		
		employee.setEid(102);
		employee.setEname("ram");
		employee.setSalary(40000);
		
		session.save(employee);
		
		session.beginTransaction().commit();
	
		//if we want to insert multiple records then we have to creating multiple object
		//and creating list
		

		}

}
