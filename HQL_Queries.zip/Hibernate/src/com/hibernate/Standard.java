package com.hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Standard {
@Id
	private int sid;
	private int division;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getDivision() {
		return division;
	}
	public void setDivision(int division) {
		this.division = division;
	}
	@Override
	public String toString() {
		return "Standard [sid=" + sid + ", division=" + division + "]";
	}
	
	

}
