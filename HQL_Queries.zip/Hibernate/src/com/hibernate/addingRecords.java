
package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class addingRecords {
	
	
	public static void main(String[] args) {
		
		
		//save()=we get new record which we have to adding 		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		Employee employee=new Employee();
		employee.setEid(103);
		employee.setEname("preeti");
		employee.setSalary(60000);
		
		session.save(employee);
		//System.out.println(employee);
		session.beginTransaction().commit();
		
	}

}
