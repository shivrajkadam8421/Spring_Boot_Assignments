package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


public class criteria1 {
	
	public static void main(String[] args) {
		// here if we want data based on non id values then get() and load()
		// methods are not applicable so at that we using criteria.
		
		
		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();

		//Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
//		Employee e=session.get(Employee.class,101);
//		System.out.println(e);
		
		
//		Criteria criteria=session.createCriteria(Employee.class);
//		criteria.add(Restrictions.eq("ename","sandhya"));
//		List<Employee> li=criteria.list();
//		System.out.println(li);
//		
		Criteria criteria=session.createCriteria(Employee.class);
	criteria.add(Restrictions.eq("salary",50000));
		List<Employee> li=criteria.list();
	
		System.out.println(li);
		
		
	}
}
