package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import java.util.ArrayList;
public class HQLQueryAllRecords {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		
	Transaction ts=session.beginTransaction();
	
	Query query=session.createQuery("from Employee where eid>:eid and salary between :lower and :upper");
	
	
	query.setParameter("eid", 3);
	
	query.setParameter("lower", 50000);
	
	query.setParameter("upper", 900000);
	
	List<Employee> list=query.list();
	
	System.out.println(list);

}
}