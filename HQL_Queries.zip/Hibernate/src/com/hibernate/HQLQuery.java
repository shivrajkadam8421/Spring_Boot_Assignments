//HQL query for delete
package com.hibernate;

import java.util.List;

import org.hibernate.Criteria;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

import java.util.ArrayList;
public class HQLQuery {
	
	
	public static void main(String[] args) {
		
		
			
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		
		
		
		Query query=session.createQuery("delete from employee where eid=empid");
		
		query.setParameter("eid", 101);
		
		query.executeUpdate();
		
		
		
	}

}
