package com.hibernate1;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.hibernate.Employee;

public class Save {
	public static void main(String[] args) {
		
		Session session=new Configuration().configure("hib.xml").addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		ArrayList<Employee> al=new ArrayList<>();
		
		Employee e1=new Employee();
		e1.setEid(4);
		e1.setEname("java");
		e1.setSalary(3000);
		
		
		Employee e2=new Employee();
		e2.setEid(9);
		e2.setEname("python");
		e2.setSalary(4000);
		
		
		
		Employee e3=new Employee();
		e3.setEid(6);
		e3.setEname("mysql");
		e3.setSalary(5000);
		
		al.add(e1);
		al.add(e2);
		al.add(e3);
		
		for(Employee a:al) {
			session.save(a);
		}
		session.beginTransaction().commit();

	}

}
