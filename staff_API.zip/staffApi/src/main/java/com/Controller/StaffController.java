package com.Controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StaffController {

	@Autowired
	SessionFactory factory;

	@RequestMapping("getStaff")
	public Staff getStaff() {
		Session session = factory.openSession();

		Staff staff = session.get(Staff.class, 1);
		return staff;

	}

	@GetMapping("getAllRecords")

	public List<Staff> getAllRecords() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Staff.class);

		List<Staff> list = criteria.list();

		return list;
	}

	@GetMapping("getOne")
	public Staff getOne() {
		Session session = factory.openSession();

		Staff staff = session.get(Staff.class, 3);
		return staff;

	}
	@GetMapping("getPerticular/{staffid}")
	public Staff getPerticular(@PathVariable int staffid) {
		Session session = factory.openSession();
		
		Criteria criteria=session.createCriteria(Staff.class);
		criteria.add(Restrictions.eq("staffid", staffid));
		
		List<Staff> list=criteria.list();
		
		return list.get(0);

	}
	
	
	@GetMapping("greaterRecords")
	public List<Staff> greaterRecords() {
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.gt("salary", 20000));

		List<Staff> list = criteria.list();

		return list;
	}

	@GetMapping("betweenEx")

	public List<Staff> betweenEx() {
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Staff.class);

		criteria.add(Restrictions.between("experience", 10, 20));

		List<Staff> list = criteria.list();

		return list;

	}

	@GetMapping("maxSalary")

	public List<Staff> maxSalary() {
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Staff.class);

		criteria.setProjection(Projections.max("salary"));

		List<Staff> list = criteria.list();

		return list;

	}

//	@PuttMapping("updateStaff")
//	public String update(@RequestBody Staff staff) {
// 
//		Session session = factory.openSession();
//		
//		session.update(staff);
//		
//		session.beginTransaction().commit();
//		
//		return "updated records";
//	}

	@PutMapping("updateStaff")
	public String updateStaff(@RequestBody Staff staff) {

		Session session = factory.openSession();

		session.update(staff);

		session.beginTransaction().commit();

		return "updated records";
	}

	@GetMapping("minExperience")

	public List<Staff> minExperience() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Staff.class);

		criteria.setProjection(Projections.min("salary"));
         List<Staff> list= criteria.list();

		return list;

	}

	@GetMapping("profileTrainer")
	public List<Staff> profileTrainer() {
		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.in("profile", "trainer"));
		List<Staff> list = criteria.list();

		return list;

	}

	@GetMapping("profileTrainer2/{profile}")
	
	public List<Staff> profileTrainer2(@PathVariable String profile){
		
		Session session=factory.openSession();
		Criteria criteria=session.createCriteria(Staff.class);
		criteria.add(Restrictions.eq("profile", profile));
		List<Staff> list=criteria.list();
		
		
		
		return list;
	}
	
	
	@DeleteMapping("delete/{staffid}")
	public String delete(@PathVariable int staffid) {
		Session session=factory.openSession();
		Staff staff=session.get(Staff.class, staffid);
		session.delete(staff);
		session.beginTransaction().commit();
		
		return "record deleted";
	}
	@PostMapping("datainserted")
	public Staff dataInserted(@RequestBody Staff staff) {
		Session session=factory.openSession();
		session.save(staff);
		session.beginTransaction().commit();
		
		return staff;
	}

//	@GetMapping("minSalaryWithName")
//	public List<Staff> minSalaryWithName(){
//		
//		Session session=factory.openSession();
//		Criteria criteria=session.createCriteria(Staff.class);
//		
//		
//	}
	
	
	@GetMapping("NotprofileTrainer")
	public List<Staff> NotprofileTrainer() {
		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		//criteria.add(Restrictions.in("profile", "trainer"));
		criteria.add(Restrictions.ne("profile", "trainner"));
		List<Staff> list = criteria.list();

		return list;

	}
	
	@GetMapping("maxSalaryWithObject")
	public Staff maxSalaryWithObject() {
		Session session=factory.openSession();
	Criteria criteria=session.createCriteria(Staff.class);
	criteria.setProjection(Projections.max("salary"));
	
	List<Integer> list=criteria.list();
	
	int maxSalary=list.get(0);
	Criteria criteria2=session.createCriteria(Staff.class);
	
	criteria2.add(Restrictions.eq("salary", maxSalary));
	
	List<Staff> list2=criteria2.list();
	
	return list2.get(0);
	}
	
	
	@GetMapping("minSalaryRecord")
	public Staff minSalaryRecord() {
		
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Staff.class);
		
		criteria.setProjection(Projections.min("salary"));
		
		List<Integer> list=criteria.list();
		
		int minSalary=list.get(0);
		
		//here first we we min salary record and using that min salary we
		//find that record for this we required another criteria
		
		
		Criteria criteria2=session.createCriteria(Staff.class);
		
		criteria2.add(Restrictions.eq("salary", minSalary));//here first we don't 
		// have min salary so first we finding using criteria min and then use it as
		// property name in restrictions.eq
		
		List<Staff> list2=criteria2.list();
		
		
		return list2.get(0);
		
	}
	
	
	@GetMapping("minExperienceRecord")
	public String minExperienceRecord() {
		
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Staff.class);
		
		criteria.setProjection(Projections.min("experience"));
		
		List<Integer> list=criteria.list();
		
		int minExperience=list.get(0);
		
		//here first we we min salary record and using that min salary we
		//find that record for this we required another criteria
		
		
		Criteria criteria2=session.createCriteria(Staff.class);
		
		criteria2.add(Restrictions.eq("experience",minExperience ));//here first we don't 
		// have min salary so first we finding using criteria min and then use it as
		// property name in restrictions.eq
		
		
		criteria2.setProjection(Projections.property("name"));
		List<String> list2=criteria2.list();
		
		
		return list2.get(0);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
