package com.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController

public class EmployeeController {

	@Autowired

	SessionFactory factory;

	/* getting particular employee based on eid */
	@GetMapping("getEmployee")

	public Employee getEmployee() {

		Session session = factory.openSession();

		Employee employee = session.get(Employee.class, 3);

		return employee;

	}

	// getting all employee records

	@GetMapping("getAllEmployee")

	public List<Employee> getAllEmployee() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		List<Employee> li = criteria.list();

		return li;
	}

	// update employee record

	@PutMapping("updateEmployee")

	public String updateEmployee(@RequestBody Employee employee) {

		Session session = factory.openSession();

		session.update(employee);

		session.beginTransaction().commit();

		return "updated successfully";
	}

	// delete employee records

	@DeleteMapping("deletedEmployee/{eid}")

	public String deletedEmployee(@PathVariable int eid) {

		Session session = factory.openSession();

		Employee employee = session.get(Employee.class, eid);

		session.delete(employee);

		session.beginTransaction().commit();

		return "deleted records";
	}

	// inserting records
	@PostMapping("saveEmployee")

	public Employee saveEmployee(@RequestBody Employee employee) {

		Session session = factory.openSession();

		session.save(employee);

		session.beginTransaction().commit();

		return employee;

	}

	// getting records based on condition
	@GetMapping("salaryBasedOnCondition")

	public List<Employee> salaryBasedOnCondition() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.add(Restrictions.le("salary", 60000));

		List<Employee> li = criteria.list();

		return li;
	}

	// getting records based on greater than condition
	@GetMapping("salaryBasedOnGeCondition")

	public List<Employee> salaryBasedOnGeCondition() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.add(Restrictions.ge("salary", 60000));

		List<Employee> li = criteria.list();

		return li;

	}

	@GetMapping("salaryBasedOnBetween")

	public List<Employee> salaryBasedOnBetween() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.add(Restrictions.between("salary", 70000, 90000));

		List<Employee> li = criteria.list();

		return li;

	}

//
	// @GetMapping("startWithName")
//		
//		public List<Employee> startWithName () {
//			
//			Session session=factory.openSession();
//			
//			Criteria criteria=session.createCriteria(Employee.class);
//			
//		criteria.add(Restrictions.ilike("ename","%s"));
//		
//		for (iterable_type iterable_element : iterable) {
//			
//		}
//		
//		return li;

//	}

	// aggrigate functions

	@RequestMapping("minSalary")

	public List<Employee> minSalary() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.setProjection(Projections.min("salary"));

		List<Employee> list = criteria.list();

		return list;

	}

	@RequestMapping("maxSalary")

	public List<Employee> maxSalary() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.setProjection(Projections.max("salary"));

		List<Employee> list = criteria.list();

		return list;

	}

	@RequestMapping("avgOfSalary")

	public List<Employee> avgOfSalary() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.setProjection(Projections.avg("salary"));

		List<Employee> list = criteria.list();

		return list;

	}

	@RequestMapping("sumOfSalary")

	public List<Employee> sumOfSalary() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.setProjection(Projections.sum("salary"));

		List<Employee> list = criteria.list();

		return list;

	}

	@RequestMapping("totalCountOfSalary")

	public List<Employee> totalCountOfSalary() {

		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Employee.class);

		criteria.setProjection(Projections.count("salary"));

		List<Employee> list = criteria.list();

		return list;

	}
	
	
@RequestMapping("oneColumn1")
	
	public List<Employee> oneColumn1(){
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		ProjectionList ps=Projections.projectionList();
		
		//ps.add(Projections.property("salary"));
		ps.add(Projections.property("ename"));
		
		criteria.setProjection(ps);
		
		List<Employee> list=criteria.list();
		
		System.out.println(list);
		 return list;
		
}	


	
}
