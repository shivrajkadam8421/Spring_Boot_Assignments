package com.controller;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="charges")
public class ProductCharges {
	
	@Id
	String productCategory;
	int discount;
	int GST;
	int deliveryCharge;
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public int getGST() {
		return GST;
	}
	public void setGST(int gST) {
		GST = gST;
	}
	public int getDeliveryCharge() {
		return deliveryCharge;
	}
	public void setDeliveryCharge(int deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	@Override
	public String toString() {
		return "ProductCharges [productCategory=" + productCategory + ", discount=" + discount + ", GST=" + GST
				+ ", deliveryCharge=" + deliveryCharge + "]";
	}
	

}
