package com.controller;

public class Charges {
	double GST;
	double delivery;
	public double getGST() {
		return GST;
	}
	public void setGST(double gST) {
		GST = gST;
	}
	public double getDelivery() {
		return delivery;
	}
	public void setDelivery(double delivery) {
		this.delivery = delivery;
	}
	@Override
	public String toString() {
		return "Charges [GST=" + GST + ", delivery=" + delivery + "]";
	}
	

}
