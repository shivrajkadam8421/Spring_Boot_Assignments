package com.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.Controller.Staff;
@RestController
public class ProductController {
	@Autowired
	SessionFactory factory;

	@RequestMapping("getProduct/{productId}")

	public Bill getProduct(@PathVariable int productId) {
		Session session = factory.openSession();

		Product product = session.load(Product.class, productId);

		Bill bill = new Bill();
		bill.setProductId(product.getProductId());
		bill.setName(product.getProductName());
		bill.setProductType(product.getProductType());
		bill.setCategory(product.getProductCategory());
		bill.setBasePrice(product.getProductPrice());

		String category = product.getProductCategory();

		ProductCharges pc = session.load(ProductCharges.class, category);

		double basePrice = product.getProductPrice();

		double discountamount = (basePrice * pc.getDiscount()) / 100;
		
		bill.setDiscount(discountamount);

		Charges charges = new Charges();

		charges.setDelivery(pc.getDeliveryCharge());

		double gstper = pc.getGST();
		double lastamount=basePrice-discountamount;
		double gstamount = (lastamount * gstper) / 100;

		charges.setGST(gstamount);
		
		bill.setCharges(charges);
		
		double finalprice=basePrice-discountamount+(pc.getDeliveryCharge()+gstamount);

		System.out.println(finalprice);

		bill.setFinalPrice(finalprice);

		return bill;
	}

	
	@RequestMapping("showAllProduct")
	
	public List<Product> showAllProduct() {
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Product.class);
		List<Product> list=criteria.list();
		
		return list;
	}
	

	@RequestMapping("showGreaterProduct")
	
	public List<Product> showGreaterProduct() {
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Product.class);
		
		criteria.add(Restrictions.gt("product_Price",35000));
		List<Product> list=criteria.list();
		
		return list;
	}
	
	@PutMapping("updateProduct")
	public String updateStaff(@RequestBody Product product) {

		Session session = factory.openSession();

		session.update(product);

		session.beginTransaction().commit();

		return "updated records";
	
	}
	@RequestMapping("maxPrice")
	
	public List<Product> maxPrice() {
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Product.class);
		
		criteria.setProjection(Projections.max("product_Price"));
		List<Product> list=criteria.list();
		
		return list;
	}
	
	
}
